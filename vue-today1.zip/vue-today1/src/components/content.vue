<template>
<div id="app">
<el-row :gutter="20">
  <el-col :span="16"><div class="grid-content bg-purple">
    <div>
 <a href=""><img src="../assets/banner.jpg" alt=""></a>
    </div>
    

<div class="content-2">
<div class="right">
  <el-row :gutter="20">
  <el-col :span="16"><div class="grid-content bg-purple">
    <a href=""><h2>用好时间、工作管理这四个软件，让2019年少留遗憾</h2></a>
<p>2018年悄然离开，有收获但是存在更多遗憾，想去的旅游没去，想学习的技能束之高阁，
  究其原因没有形成时间管理意识，不清楚在何时做何事、不知道哪些工...</p>
<div class="tubiao">
<img src="../assets/tubiao.png" alt="" >
</div>
<div class="wenzi">
<span>策划鼠</span>
<div class="tubiao-1">
<a href=""><img src="../assets/xinxi.png" alt=""></a>
</div>
<div class="tubiao-2">
<a href=""><img src="../assets/xin.png" alt=""></a>
</div>
</div>


    
    </div></el-col>
  <el-col :span="8"><div class="grid-content bg-purple">
        <a href=""><img src="../assets/today.png" alt=""></a>
    </div></el-col>
</el-row>

</div>


</div>







<div class="content-2">
<div class="right">
  <el-row :gutter="20">
  <el-col :span="16"><div class="grid-content bg-purple">
    <a href=""><h2>用好时间、工作管理这四个软件，让2019年少留遗憾</h2></a>
<p>2018年悄然离开，有收获但是存在更多遗憾，想去的旅游没去，想学习的技能束之高阁，
  究其原因没有形成时间管理意识，不清楚在何时做何事、不知道哪些工...</p>
<div class="tubiao">
<img src="../assets/tubiao.png" alt="" >
</div>
<div class="wenzi">
<span>策划鼠</span>
<div class="tubiao-1">
<a href=""><img src="../assets/xinxi.png" alt=""></a>
</div>
<div class="tubiao-2">
<a href=""><img src="../assets/xin.png" alt=""></a>
</div>
</div>


    
    </div></el-col>
  <el-col :span="8"><div class="grid-content bg-purple">
        <a href=""><img src="../assets/today.png" alt=""></a>
    </div></el-col>
</el-row>

</div>
</div>

    



<div class="content-2">
<div class="right">
  <el-row :gutter="20">
  <el-col :span="16"><div class="grid-content bg-purple">
    <a href=""><h2>用好时间、工作管理这四个软件，让2019年少留遗憾</h2></a>
<p>2018年悄然离开，有收获但是存在更多遗憾，想去的旅游没去，想学习的技能束之高阁，
  究其原因没有形成时间管理意识，不清楚在何时做何事、不知道哪些工...</p>
<div class="tubiao">
<img src="../assets/tubiao.png" alt="" >
</div>
<div class="wenzi">
<span>策划鼠</span>
<div class="tubiao-1">
<a href=""><img src="../assets/xinxi.png" alt=""></a>
</div>
<div class="tubiao-2">
<a href=""><img src="../assets/xin.png" alt=""></a>
</div>
</div>


    
    </div></el-col>
  <el-col :span="8"><div class="grid-content bg-purple">
        <a href=""><img src="../assets/today.png" alt=""></a>
    </div></el-col>
</el-row>

</div>


</div>







<div class="content-2">
<div class="right">
  <el-row :gutter="20">
  <el-col :span="16"><div class="grid-content bg-purple">
    <a href=""><h2>用好时间、工作管理这四个软件，让2019年少留遗憾</h2></a>
<p>2018年悄然离开，有收获但是存在更多遗憾，想去的旅游没去，想学习的技能束之高阁，
  究其原因没有形成时间管理意识，不清楚在何时做何事、不知道哪些工...</p>
<div class="tubiao">
<img src="../assets/tubiao.png" alt="" >
</div>
<div class="wenzi">
<span>策划鼠</span>
<div class="tubiao-1">
<a href=""><img src="../assets/xinxi.png" alt=""></a>
</div>
<div class="tubiao-2">
<a href=""><img src="../assets/xin.png" alt=""></a>
</div>
</div>


    
    </div></el-col>
  <el-col :span="8"><div class="grid-content bg-purple">
        <a href=""><img src="../assets/today.png" alt=""></a>
    </div></el-col>
</el-row>

</div>


</div>








<div class="content-2">
<div class="right">
  <el-row :gutter="20">
  <el-col :span="16"><div class="grid-content bg-purple">
    <a href=""><h2>用好时间、工作管理这四个软件，让2019年少留遗憾</h2></a>
<p>2018年悄然离开，有收获但是存在更多遗憾，想去的旅游没去，想学习的技能束之高阁，
  究其原因没有形成时间管理意识，不清楚在何时做何事、不知道哪些工...</p>
<div class="tubiao">
<img src="../assets/tubiao.png" alt="" >
</div>
<div class="wenzi">
<span>策划鼠</span>
<div class="tubiao-1">
<a href=""><img src="../assets/xinxi.png" alt=""></a>
</div>
<div class="tubiao-2">
<a href=""><img src="../assets/xin.png" alt=""></a>
</div>
</div>


    
    </div></el-col>
  <el-col :span="8"><div class="grid-content bg-purple">
        <a href=""><img src="../assets/today.png" alt=""></a>
    </div></el-col>
</el-row>

</div>


</div>
    </div></el-col>
  <el-col :span="8"><div class="grid-content bg-purple">

    
    
    
    </div></el-col>
</el-row>

</div>

</template>

<script>
export default {
  
}
</script>


<style scoped>
a{
  text-decoration: none;
}
    .el-row {
    margin-bottom: 20px;
    
  }
  .last-child {
      margin-bottom: 0;
    }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background:  white;
  }
  .bg-purple {
    background: white;
  }
  .bg-purple-light {
    background:  white;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 36px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
.neirong{
width: 70%;
margin: 0 auto;
}
#app img{
  width: 100%;
}
.content-2{
  width: 100%;
}
.content-2 h2{
    margin-top: 9%;
     

    font-size: 18px;
    font-weight: 700;
    line-height: 1.5;
}
.content-2 p{
     color:#969696;
      margin-top: 1%;
}
.content-2 img{
  margin-top: 20%;
  float: right;
  width: 100%;
}
.right p{
     display: block;
    margin-block-start: 1em;
    margin-block-end: 1em;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
}
.tubiao{
  float: left;
  width: 10%;
}
.tubiao img{
width: 100%;
}
.wenzi{
  margin-top: 2%;
  float: left;
  width: 90%;
}
.wenzi span{
    float: left;
  color: #969696;
  padding-left: 3%;
  font-size: 0.8em;
}
.tubiao-1{
  margin-left: 3%;
  background: red;
  float: left;
  width: 10%;
}
.tubiao-1 img{
margin-top: -0.1%;
}
.tubiao-2{
  float: left;
  width: 10%;
}
.tubiao-2 img{
margin-top: 1.8%;
}
</style>
