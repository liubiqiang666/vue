<template>
  <div class="nav">
<el-row>
  <el-col :span="24"><div class="grid-content bg-purple-dark"></div></el-col>
</el-row>

<div class="today">
<content-t></content-t>
</div>

  </div>
</template>

<script>
import content from './components/content'
export default{
 components:{
   'content-t':content
 }
 }

</script>

<style>
*{
  margin: 0;
  padding: 0;
}
.el-row {
    margin-bottom: 20px;
 
  }
  .el-col {
    border-radius: 4px;
  }
  .bg-purple-dark {
    background: #99a9bf;
  }
  .bg-purple {
    background: #d3dce6;
  }
  .bg-purple-light {
    background: #e5e9f2;
  }
  .grid-content {
    border-radius: 4px;
    min-height: 72px;
  }
  .row-bg {
    padding: 10px 0;
    background-color: #f9fafc;
  }
 .today{
   width:70%;
   height: 800px;
   margin: 0 auto;
 }
</style>
